/**
 * Re-run the architectural proof's BASIC layout audit:
 *   npx vite-node scripts/check-art-layout.ts
 *   npx vite-node scripts/check-art-layout.ts --checkout-improved
 *
 * Uses the actual renderer layout, manifest anchors, and authored fixture ground
 * corners. No browser, simulation, screenshot fixtures, or new test framework.
 * Checks branded bays and either matching checkout state. Does not validate
 * legacy security/marketing footprints, full actor silhouettes, depth ordering,
 * doorway leaf occlusion, or actors moving around one another; browser QA does.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PROOF_STORE, proofPoint, type ProofPoint } from '../src/proofStoreLayout.ts';

const root = fileURLToPath(new URL('../', import.meta.url));
const read = (relative: string) => JSON.parse(fs.readFileSync(path.join(root, relative), 'utf8'));
const manifest = read('public/art/architectural-proof/manifest.json') as {
  sprites: Record<string, { url: string; width: number; height: number; anchor: ProofPoint }>;
};
interface FixtureMetadata {
  url: string;
  width: number;
  height: number;
  groundCorners: ProofPoint[];
  groundAnchorPixels: ProofPoint;
}
const geometryContracts = ['fixtures-extraction.json', 'merchandising-extraction.json', 'branded-counters-contract.json'];
const extractedGeometry = geometryContracts.flatMap(file => Object.values((read(`public/art/architectural-proof/${file}`) as { sprites: Record<string, FixtureMetadata> }).sprites));
const shell = read('public/art/architectural-proof/interior-shell-metadata.json') as {
  width: number;
  height: number;
  ground: { floorCorners: Record<'back' | 'right' | 'front' | 'left', ProofPoint>; entranceThreshold: ProofPoint };
};
const checkoutImproved = process.argv.includes('--checkout-improved');
const basic = PROOF_STORE.modules({ checkout: checkoutImproved ? 1 : 0 });
const failures: string[] = [];
const EPSILON = 1e-7;

function cross(a: ProofPoint, b: ProofPoint, p: ProofPoint) {
  return (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x);
}
/** Convex polygons, either winding. Tolerance is world units perpendicular to an edge. */
function inside(point: ProofPoint, polygon: readonly ProofPoint[], tolerance = 0) {
  let winding = 0;
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], b = polygon[(i + 1) % polygon.length];
    const distance = cross(a, b, point) / Math.hypot(b.x - a.x, b.y - a.y);
    if (Math.abs(distance) <= tolerance + EPSILON) continue;
    const sign = Math.sign(distance);
    if (winding && sign !== winding) return false;
    winding = sign;
  }
  return true;
}
function onSegment(a: ProofPoint, b: ProofPoint, p: ProofPoint) {
  return Math.abs(cross(a, b, p)) < EPSILON &&
    p.x >= Math.min(a.x, b.x) - EPSILON && p.x <= Math.max(a.x, b.x) + EPSILON &&
    p.y >= Math.min(a.y, b.y) - EPSILON && p.y <= Math.max(a.y, b.y) + EPSILON;
}
function segmentsIntersect(a: ProofPoint, b: ProofPoint, c: ProofPoint, d: ProofPoint) {
  const abC = cross(a, b, c), abD = cross(a, b, d), cdA = cross(c, d, a), cdB = cross(c, d, b);
  return (abC * abD < 0 && cdA * cdB < 0) ||
    onSegment(a, b, c) || onSegment(a, b, d) || onSegment(c, d, a) || onSegment(c, d, b);
}
function intersectsFootprint(a: ProofPoint, b: ProofPoint, polygon: readonly ProofPoint[]) {
  return inside(a, polygon) || inside(b, polygon) ||
    polygon.some((c, i) => segmentsIntersect(a, b, c, polygon[(i + 1) % polygon.length]));
}
const samePoint = (a: ProofPoint, b: ProofPoint) => Math.hypot(a.x - b.x, a.y - b.y) < 0.001;

// The source geometry and renderer geometry must stay in agreement.
assert.equal(manifest.sprites[PROOF_STORE.shellKey].width, shell.width);
assert.equal(manifest.sprites[PROOF_STORE.shellKey].height, shell.height);
for (const [i, key] of (['back', 'right', 'front', 'left'] as const).entries()) {
  const point = shell.ground.floorCorners[key];
  assert.ok(samePoint(PROOF_STORE.floorCorners[i], proofPoint(point.x, point.y)), `Floor corner ${key} disagrees with source metadata`);
}
assert.ok(samePoint(PROOF_STORE.entrance, proofPoint(shell.ground.entranceThreshold.x, shell.ground.entranceThreshold.y)));

const footprints = basic.map(module => {
  assert.ok(module.key, `Basic module ${module.name} has no sprite key`);
  const sprite = manifest.sprites[module.key];
  assert.ok(sprite, `Missing manifest sprite ${module.key}`);
  const geometry = extractedGeometry.find(entry => entry.url === sprite.url);
  assert.ok(geometry, `Missing authored basic ground footprint for ${module.key}`);
  assert.equal(sprite.width, geometry.width, `Width mismatch for ${module.key}`);
  assert.equal(sprite.height, geometry.height, `Height mismatch for ${module.key}`);
  // Actual sprite anchor matters: do not assume a bottom-centre or footprint-centre anchor.
  const anchor = { x: sprite.anchor.x * sprite.width, y: sprite.anchor.y * sprite.height };
  assert.ok(samePoint(anchor, geometry.groundAnchorPixels), `Ground anchor mismatch for ${module.key}`);
  const scale = module.width / sprite.width;
  const polygon = geometry.groundCorners.map(p => ({ x: module.x + (p.x - anchor.x) * scale, y: module.y + (p.y - anchor.y) * scale }));
  for (const [i, p] of polygon.entries()) {
    if (!inside(p, PROOF_STORE.floorCorners, 1)) failures.push(`${module.name} footprint corner ${i} is outside the floor`);
  }
  return { name: module.name, polygon };
});
assert.equal(footprints.length, 7, 'This audit targets the seven approved basic fixtures; review coverage if the layout changes.');

const actors = [PROOF_STORE.ownerPosition, ...PROOF_STORE.workPositions];
for (const [index, point] of actors.entries()) {
  if (!inside(point, PROOF_STORE.floorCorners, 1)) failures.push(`Stationary actor ${index} is outside the floor`);
  for (const fixture of footprints) if (inside(point, fixture.polygon)) failures.push(`Stationary actor ${index} is inside ${fixture.name}`);
}

let variants = 0;
let routeLegs = 0;
let sampledInteriorPoints = 0;
let exemptSidewalkLegs = 0;
for (let index = 0; index < 5; index++) {
  for (const purchase of [false, true]) for (const queued of [false, true]) {
    variants++;
    const name = `customer ${index} purchase=${purchase} queued=${queued}`;
    const route = PROOF_STORE.customerRoute(index, purchase, queued);
    assert.ok(route.length > 4, `${name} has no complete route`);
    assert.ok(samePoint(route[0], PROOF_STORE.sidewalk) && samePoint(route.at(-1)!, PROOF_STORE.sidewalk), `${name} must begin and end on the sidewalk`);
    assert.ok(samePoint(route[1], PROOF_STORE.entrance) && samePoint(route.at(-2)!, PROOF_STORE.entrance), `${name} must cross the actual entrance`);
    for (let leg = 0; leg < route.length - 1; leg++) {
      routeLegs++;
      const a = route[leg], b = route[leg + 1];
      for (const fixture of footprints) {
        if (intersectsFootprint(a, b, fixture.polygon)) failures.push(`${name}, leg ${leg} intersects ${fixture.name}`);
      }
      // The first/last sidewalk approach necessarily lies outside the shop floor.
      if (leg === 0 || leg === route.length - 2) { exemptSidewalkLegs++; continue; }
      // Retains the original 101 samples per leg, in addition to exact fixture tests.
      for (let sample = 0; sample <= 100; sample++) {
        sampledInteriorPoints++;
        const t = sample / 100;
        const point = { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
        if (!inside(point, PROOF_STORE.floorCorners, 1)) {
          failures.push(`${name}, leg ${leg}, sample ${sample} leaves the floor`);
          break;
        }
      }
    }
  }
}

console.log(JSON.stringify({
  status: failures.length ? 'failed' : 'passed',
  scope: `Common Signal fixture ground geometry with ${checkoutImproved ? 'improved' : 'starter'} checkout`,
  geometryContracts,
  fixtureFootprints: footprints.length,
  stationaryActorPositions: actors.length,
  customerRouteVariants: variants,
  exactRouteLegChecks: routeLegs,
  sampledInteriorPoints,
  exemptSidewalkLegs,
  failures,
  limits: [
    'Checks feet and authored fixture ground polygons, not full visual silhouettes or actor-to-actor spacing.',
    'Legacy security/marketing footprints, decorative lighting, entrance-leaf occlusion, sprite depth, labels, and busy scenes require browser visual QA.',
    'Floor geometry is artist-authored; 1 world-unit tolerance handles the approximate entrance threshold.',
  ],
}, null, 2));
if (failures.length) process.exitCode = 1;
