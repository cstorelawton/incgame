import { Container, Graphics, Matrix, Polygon, Sprite, Text, type Texture } from 'pixi.js';
export const PROOF_PROPERTY_IDS = new Set(['p1', 'p2', 'p3']);
export const PROOF_CITY_CAMERA = { x: 550, y: 220, width: 560, height: 650 };
interface Point { x: number; y: number }
interface Property { id: string; name: string; owner: 'available' | 'player' | 'rival' }
type Art = Record<string, { texture: Texture; anchor: Point }>;
const SLOPE = Math.tan(Math.PI / 6);
const PARCELS = [
  { id: 'p1', x: 549.22, y: 258.56, key: 'proof-building-shop', width: 155 },
  { id: 'p2', x: 663.18, y: 303.22, key: 'proof-building-apartments', width: 115 },
  { id: 'p3', x: 439.88, y: 310.15, key: 'proof-building-office', width: 175 },
];
function poly(g: Graphics, points: Point[], color: number) { g.poly(points.flatMap(p => [p.x, p.y])).fill(color); }
function road(g: Graphics, intercept: number, direction: number) {
  const slope = SLOPE * direction;
  const a = { x: -1300, y: intercept + slope * (-1300 - 550) };
  const b = { x: 2300, y: intercept + slope * (2300 - 550) };
  const normal = { x: -slope / Math.hypot(1, slope), y: 1 / Math.hypot(1, slope) };
  const ribbon = (half: number, color: number) => poly(g, [{ x: a.x + normal.x * half, y: a.y + normal.y * half }, { x: b.x + normal.x * half, y: b.y + normal.y * half }, { x: b.x - normal.x * half, y: b.y - normal.y * half }, { x: a.x - normal.x * half, y: a.y - normal.y * half }], color);
  ribbon(49, 0xf1f0e7); ribbon(39, 0xb8c0bb); ribbon(37.5, 0x8e9998);
  for (let x = -1200; x < 2300; x += 72) g.moveTo(x, intercept + slope * (x - 550)).lineTo(x + 27, intercept + slope * (x + 27 - 550)).stroke({ color: 0xeaece5, width: 2 });
}
function building(layer: Container, art: Art, key: string, x: number, y: number, width: number) {
  const asset = art[key]; if (!asset) return null;
  const sprite = new Sprite(asset.texture); sprite.anchor.set(asset.anchor.x, asset.anchor.y); sprite.scale.set(width / asset.texture.width); sprite.position.set(x, y); sprite.zIndex = y; layer.addChild(sprite); return sprite;
}

/** Transparent wordmark planes share the p1 building's exact fascia geometry. */
function addFascia(sprite: Sprite, art: Art) {
  const asset = art['proof-brand-wordmark']; if (!asset) return;
  for (const [ax, ay, bx, by, dx, dy] of [[17, 351, 251, 467, 17, 369], [349, 467, 571, 362, 349, 485]]) {
    const mark = new Sprite(asset.texture); mark.anchor.set(0);
    // The PNG's padding remains transparent, keeping the wordmark inside the fascia.
    mark.setFromMatrix(new Matrix((bx - ax) / asset.texture.width, (by - ay) / asset.texture.width, (dx - ax) / asset.texture.height, (dy - ay) / asset.texture.height, ax - sprite.anchor.x * sprite.texture.width, ay - sprite.anchor.y * sprite.texture.height));
    sprite.addChild(mark);
  }
}

/** One architectural proof block. Surrounding buildings are scenery, never new properties. */
export function buildProofCity(world: Container, art: Art, properties: Property[], selected: string | null, select: (id: string) => void) {
  const ground = new Graphics().rect(-1800, -1800, 4200, 4200).fill(0xd9ddd1); ground.zIndex = -1000;
  for (const intercept of [-270, 115, 500, 885]) road(ground, intercept, 1);
  for (const intercept of [-315, 70, 455, 840]) road(ground, intercept, -1);
  // A shared paved courtyard, without separate property plinths. The selected
  // shop's chamfered doorway connects through the courtyard to the public sidewalk.
  poly(ground, [{ x: 511, y: 147 }, { x: 747, y: 283 }, { x: 511, y: 419 }, { x: 275, y: 283 }], 0xdedbd2);
  ground.moveTo(549.22, 267).lineTo(549.22, 408).stroke({ color: 0xf1eee4, width: 22 });
  for (let y = 290; y < 403; y += 22) ground.moveTo(538.22, y).lineTo(560.22, y).stroke({ color: 0xd3d2c7, width: .8 });
  const along = { x: Math.cos(Math.PI / 6), y: Math.sin(Math.PI / 6) };
  const across = { x: -along.y, y: along.x };
  for (const center of [{ x: 573, y: 128 }, { x: 449, y: 441 }]) for (let step = -2; step <= 2; step++) {
    const x = center.x + along.x * step * 10, y = center.y + along.y * step * 10;
    poly(ground, [{ x: x + across.x * 30, y: y + across.y * 30 }, { x: x + across.x * 30 + along.x * 5, y: y + across.y * 30 + along.y * 5 }, { x: x - across.x * 30 + along.x * 5, y: y - across.y * 30 + along.y * 5 }, { x: x - across.x * 30, y: y - across.y * 30 }], 0xf1f1e9);
  }
  world.addChild(ground);
  const architecture = new Container(); architecture.sortableChildren = true; architecture.zIndex = 0; world.addChild(architecture);
  // Dense neighboring blocks extend past the camera. No detached parcel bases.
  const surrounding = [
    { x: 140, y: 40, key: 'proof-building-apartments', width: 118 },
    { x: 260, y: 90, key: 'proof-building-shop', width: 145 },
    { x: 150, y: 180, key: 'proof-building-office', width: 175 },
    { x: 810, y: 60, key: 'proof-building-office', width: 180 },
    { x: 940, y: 115, key: 'proof-building-apartments', width: 120 },
    { x: 820, y: 210, key: 'proof-building-shop', width: 150 },
    { x: 180, y: 435, key: 'proof-building-shop', width: 160 },
    { x: 260, y: 540, key: 'proof-building-apartments', width: 115 },
    { x: 115, y: 555, key: 'proof-building-office', width: 175 },
    { x: 840, y: 440, key: 'proof-building-apartments', width: 125 },
    { x: 960, y: 510, key: 'proof-building-shop', width: 155 },
    { x: 830, y: 585, key: 'proof-building-office', width: 180 },
    { x: 455, y: 640, key: 'proof-building-office', width: 185 },
    { x: 590, y: 690, key: 'proof-building-shop', width: 155 },
    { x: 510, y: 790, key: 'proof-building-apartments', width: 120 },
    { x: 465, y: -125, key: 'proof-building-shop', width: 160 },
    { x: 600, y: -65, key: 'proof-building-office', width: 170 },
    { x: 490, y: 15, key: 'proof-building-apartments', width: 113 },
  ];
  for (const node of surrounding) building(architecture, art, node.key, node.x, node.y, node.width);
  const markers = new Container(); markers.zIndex = 10000; world.addChild(markers);
  for (const parcel of PARCELS) {
    const property = properties.find(p => p.id === parcel.id); if (!property) continue;
    const key = parcel.id === 'p1' && art['proof-building-branded'] ? 'proof-building-branded' : parcel.key;
    const sprite = building(architecture, art, key, parcel.x, parcel.y, parcel.width);
    if (sprite) { if (parcel.id === 'p1') addFascia(sprite, art); sprite.eventMode = 'static'; sprite.cursor = 'pointer'; sprite.on('pointertap', () => select(property.id)); }
    const active = selected === property.id;
    const color = property.owner === 'player' ? 0x315d4b : property.owner === 'rival' ? 0xa36647 : 0x627777;
    const pin = new Graphics().circle(parcel.x, parcel.y + 10, active ? 9 : 7).fill(0xfaf8ee).stroke({ color, width: active ? 3 : 2 });
    pin.eventMode = 'static'; pin.cursor = 'pointer'; pin.hitArea = new Polygon([parcel.x - 23, parcel.y - 13, parcel.x + 23, parcel.y - 13, parcel.x + 23, parcel.y + 33, parcel.x - 23, parcel.y + 33]); pin.on('pointertap', () => select(property.id)); markers.addChild(pin);
    if (active) {
      const name = new Text({ text: property.name, style: { fontFamily: 'Arial, sans-serif', fontSize: 17, fill: 0x25463b, fontWeight: '600' } }); name.anchor.set(.5); name.position.set(parcel.x, parcel.y + 34);
      const backing = new Graphics().roundRect(parcel.x - name.width / 2 - 10, parcel.y + 20, name.width + 20, 28, 5).fill({ color: 0xfffdf4, alpha: .96 }); markers.addChild(backing, name);
    }
  }
}
