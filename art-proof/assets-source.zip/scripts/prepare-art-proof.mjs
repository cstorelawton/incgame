// Packs approved proof assets only; does not generate or repaint artwork.
import fs from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';

const directory = path.resolve('public/art/architectural-proof');
const city = JSON.parse(await fs.readFile(path.join(directory, 'city-contract.json'), 'utf8'));
const fixtures = JSON.parse(await fs.readFile(path.join(directory, 'fixtures-extraction.json'), 'utf8'));
const shell = JSON.parse(await fs.readFile(path.join(directory, 'interior-shell-metadata.json'), 'utf8'));
const merchandising = JSON.parse(await fs.readFile(path.join(directory, 'merchandising-extraction.json'), 'utf8'));
const storefront = JSON.parse(await fs.readFile(path.join(directory, 'branded-building-contract.json'), 'utf8'));
const counters = JSON.parse(await fs.readFile(path.join(directory, 'branded-counters-contract.json'), 'utf8'));
const characters = JSON.parse(await fs.readFile(path.join(directory, 'characters-manifest.json'), 'utf8'));
const branding = JSON.parse(await fs.readFile(path.join(directory, 'branding/brand-contract.json'), 'utf8'));
const addedMetadata = { ...merchandising.sprites, ...counters.sprites, ...characters.sprites, ...branding.assets };
const inputs = [
  ['proof-building-shop', 'building-shop-corrected.png', city.sprites.shop.anchor],
  ['proof-building-apartments', 'building-apartments-corrected.png', city.sprites.apartments.anchor],
  ['proof-building-office', 'building-office-final.png', city.sprites.office.anchor],
  ['proof-interior', 'interior-shell.png', shell.ground.groundAnchor],
  ['proof-counter', 'fixture-counter-basic.png', fixtures.sprites['fixture-counter-basic'].groundAnchorNormalized],
  ['proof-display', 'fixture-display-basic.png', fixtures.sprites['fixture-display-basic'].groundAnchorNormalized],
  ['proof-checkin', 'fixture-welcome-basic.png', fixtures.sprites['fixture-welcome-basic'].groundAnchorNormalized],
  ['proof-building-branded', 'building-shop-branded.png', storefront.anchor],
  ...Object.entries(addedMetadata).map(([key, asset]) => [key, asset.url.replace('/art/architectural-proof/', ''), asset.anchor ?? asset.groundAnchorNormalized]),
];
const sprites = {};
const frames = {};
const composites = [];
const atlasWidth = 4096;
const padding = 8;
let left = padding, top = padding, rowHeight = 0;
const prepared = await Promise.all(inputs.map(async ([key, file, anchor]) => ({ key, file, anchor, input: path.join(directory, file), ...await sharp(path.join(directory, file)).metadata() })));
// Largest-first shelves reduce wasted texture space while retaining source resolution.
prepared.sort((a, b) => b.height - a.height);
for (const { key, file, anchor, input, width, height, hasAlpha } of prepared) {
  if (!width || !height || !hasAlpha) throw new Error(`${file} requires RGBA dimensions`);
  if (left + width + padding > atlasWidth) { left = padding; top += rowHeight + padding * 2; rowHeight = 0; }
  sprites[key] = { url: `/art/architectural-proof/${file}`, width, height, anchor, animation: addedMetadata[key]?.animation ?? { type: 'static', frames: 1 } };
  frames[key] = { frame: { x: left, y: top, w: width, h: height }, rotated: false, trimmed: false, spriteSourceSize: { x: 0, y: 0, w: width, h: height }, sourceSize: { w: width, h: height }, anchor };
  composites.push({ input, left, top });
  left += width + padding * 2;
  rowHeight = Math.max(rowHeight, height);
}
const atlasHeight = Math.ceil((top + rowHeight + padding) / 256) * 256;
await sharp({ create: { width: atlasWidth, height: atlasHeight, channels: 4, background: '#00000000' } }).composite(composites).png().toFile(path.join(directory, 'atlas.png'));
await fs.writeFile(path.join(directory, 'atlas.json'), JSON.stringify({ frames, meta: { app: 'Dispensary Inc. proof packer', image: 'atlas.png', format: 'RGBA8888', size: { w: atlasWidth, h: atlasHeight }, scale: '1' } }, null, 2) + '\n');
await fs.writeFile(path.join(directory, 'manifest.json'), JSON.stringify({
  version: 1,
  scope: 'One Old Town block and Maple & Main interior; proof for review.',
  projection: { target: 'Orthographic isometric, ground axes ±30 degrees', assetGeometry: 'Artist-rendered approximate; measured footprint corners retained in source contracts.' },
  scale: { storyMeters: 3.2, doorwayMeters: 2.1, adultMeters: 1.75, counterMeters: 1 },
  lighting: 'Upper-left broad daylight; restrained face shading',
  palette: ['#d9d3c4', '#b77c63', '#edeae1', '#59676b', '#8da5a5', '#315d4b'],
  sprites,
  atlas: '/art/architectural-proof/atlas.json',
  actors: 'COMMON SIGNAL adult sprite lineup, deterministic assigned-employee identity, original visual-only transform animation. See characters-manifest.json.',
  brand: { name: 'COMMON SIGNAL', palette: ['#F5F1E8', '#202533', '#3155E7', '#F58245'], mark: 'circle over two horizontal bars' },
  sources: ['source/city-buildings-corrected.png', 'source/city-office-repaired.png', 'source/interior-shell-corrected-original.png', 'source/fixtures-original.png', 'source/building-shop-brand-edit.png', 'source/merchandising-original.png', 'source/counters-branded-original.png', 'source/characters-lineup-clean-original.png', 'branding/svg/'],
  geometryContracts: ['city-contract.json', 'interior-shell-metadata.json', 'fixtures-extraction.json', 'branded-building-contract.json', 'merchandising-extraction.json', 'branded-counters-contract.json', 'characters-manifest.json', 'branding/brand-contract.json'],
}, null, 2) + '\n');
console.log(`Packed ${inputs.length} independent RGBA sprites into ${atlasWidth}×${atlasHeight}; manifest ready.`);
