/** Architectural proof presentation data only. Never changes simulation or saves. */
export interface ProofPoint { x: number; y: number }
export interface ProofModule extends ProofPoint {
  name: string;
  key: string | null;
  width: number;
  /** Optional explicit render order, used for the floor rug. */
  z?: number;
}

const SCALE = 1000 / 1536;
const NATIVE_ANCHOR = { x: 722, y: 891 };
const WORLD_ANCHOR = { x: 560, y: 780 };

/** Convert an approved shell source pixel to renderer world coordinates. */
export function proofPoint(nativeX: number, nativeY: number): ProofPoint {
  return {
    x: WORLD_ANCHOR.x + (nativeX - NATIVE_ANCHOR.x) * SCALE,
    y: WORLD_ANCHOR.y + (nativeY - NATIVE_ANCHOR.y) * SCALE,
  };
}

function moduleAt(name: string, key: string | null, x: number, y: number, nativeWidth: number, z?: number): ProofModule {
  return { name, key, ...proofPoint(x, y), width: nativeWidth * SCALE, ...(z === undefined ? {} : { z }) };
}

/** Calibrated against the shell's 226px wall height / 3.2m, not arbitrary image sizes. */
function modules(upgrades: Record<string, number> = {}): ProofModule[] {
  const result: ProofModule[] = [];
  if (upgrades.interior) result.push(moduleAt('Brand floor mat', 'proof-brand-floor', 760, 745, 350, -900));

  // Scale each branded bay from its authored 1.6m height against the same shell.
  // The display improvement adds light overlays in the renderer; occupancy stays fixed.
  const flowerWidth = 447 * 0.225440313111546;
  const edibleWidth = 448 * 0.225440313111546;
  const concentrateWidth = 449 * 0.22456140350877193;
  const merchWidth = 428 * 0.21942857142857145;
  result.push(
    moduleAt('Rear product shelf west', 'proof-display-flower', 750, 345, flowerWidth),
    moduleAt('Rear product shelf middle', 'proof-display-edibles', 890, 415, edibleWidth),
    moduleAt('Rear product shelf east', 'proof-display-concentrates', 1030, 485, concentrateWidth),
    moduleAt('Floor apparel shelf', 'proof-merch', 420, 620, merchWidth),
    moduleAt('Floor product shelf east', 'proof-display-flower', 540, 680, flowerWidth),
  );

  // The matched starter/improved counters share one footprint-centre socket.
  // No legacy gold counter or extra POS station is added to the branded layout.
  result.push(moduleAt('Service counter', upgrades.checkout ? 'proof-counter-improved' : 'proof-counter-starter', 750, 600, 221.4));
  result.push(moduleAt('Welcome and check-in', 'proof-checkin', 1170, 560, 88.3));

  // Physical improvements stay visible. Their sockets avoid the open doorway and
  // customer aisle rather than replacing the approved shell with an unrelated room.
  if (upgrades.security) result.push(moduleAt('Entry security', 'security', 1175, 675, 58));
  if (upgrades.marketing) result.push(moduleAt('Sidewalk campaign board', 'marketing', 1295, 668, 48));
  return result;
}

/**
 * Entry → browsing → optional queue/service → exit. Every waypoint is a ground
 * position. The central counter footprint occupies approximately x640..860,
 * y545..655 in native pixels; all customer legs stay on its east/front side.
 * Routes are representative activity, never a second economic simulation.
 */
function customerRoute(index: number, purchase: boolean, queued: boolean): ProofPoint[] {
  const slot = Math.abs(Math.trunc(index)) % 3;
  const browse: readonly [number, number][] = [
    [945, 515], [938, 550], [976, 576],
  ];
  const queues: readonly [number, number][] = [
    [885, 700], [935, 715], [985, 730],
  ];
  const native: [number, number][] = [
    [1210, 686], // Exterior sidewalk, clear of the outward-swinging door leaf.
    [1175, 653], // Actual connected entrance threshold.
    [1115, 655],
    [1010, 665],
    [980, 610],
    [browse[slot][0], browse[slot][1]],
    [950, 600],
  ];
  if (purchase) {
    native.push([980, 680]);
    if (queued) native.push([queues[slot][0], queues[slot][1]]);
    native.push([875, 667]); // Service position outside the counter's front tip.
    native.push([965, 697]);
  } else {
    native.push([1020, 650]);
  }
  native.push([1070, 675], [1115, 655], [1175, 653], [1210, 686]);
  return native.map(([x, y]) => proofPoint(x, y));
}

export const PROOF_STORE = {
  shellKey: 'proof-interior',
  width: 1000,
  anchorPosition: WORLD_ANCHOR,
  personHeight: 124 * SCALE,
  ownerPosition: proofPoint(690, 500),
  workPositions: [
    proofPoint(810, 550),
    proofPoint(475, 550),
    proofPoint(1050, 540),
    proofPoint(300, 600),
    proofPoint(580, 760),
    proofPoint(620, 680),
  ] as readonly ProofPoint[],
  floorCorners: [proofPoint(628, 244), proofPoint(1307, 583), proofPoint(722, 891), proofPoint(152, 553)] as readonly ProofPoint[],
  entrance: proofPoint(1175, 653),
  sidewalk: proofPoint(1210, 686),
  modules,
  customerRoute,
};
