# COMMON SIGNAL asset sources

Reusable original sprite kit for the Dispensary Inc. visual proof. This is an art-source package, not the entire runnable game.

See public/art/architectural-proof/README.md for provenance, accepted assets, geometry and limitations. The pack contains approved PNGs, original generated sources, editable outlined SVGs, metadata, extraction scripts, shared atlas and renderer placement data. Reference photographs and Coffee Inc artwork are excluded.

To rebuild the atlas: npm install, then npm run pack. Individual extraction recipes are under public/art/architectural-proof/source. To rebuild vector branding, install Python fonttools, then run python3 public/art/architectural-proof/branding/source/build-brand.py. Manrope and its SIL OFL license are included.

Generated raster art is not a layered PSD or a full skeletal animation rig. Art-direction ages are not game state. Full game run instructions and browser proof evidence remain in the project.
